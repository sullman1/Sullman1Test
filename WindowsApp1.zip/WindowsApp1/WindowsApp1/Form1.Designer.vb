﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ImageComboBoxEdit1 = New DevExpress.XtraEditors.ImageComboBoxEdit()
        Me.GridLookUpEdit1 = New DevExpress.XtraEditors.GridLookUpEdit()
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.TreeList1 = New DevExpress.XtraTreeList.TreeList()
        Me.colEData = New DevExpress.XtraTreeList.Columns.TreeListColumn()
        Me.colImageOrderList = New DevExpress.XtraTreeList.Columns.TreeListColumn()
        Me.colImage = New DevExpress.XtraTreeList.Columns.TreeListColumn()
        Me.DPSTreeListBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ds_DPSTreelist = New WindowsApp1.Ds_DPSTreelist()
        Me.DPS_TreeListTableAdapter = New WindowsApp1.Ds_DPSTreelistTableAdapters.DPS_TreeListTableAdapter()
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton()
        CType(Me.ImageComboBoxEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TreeList1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DPSTreeListBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ds_DPSTreelist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ImageComboBoxEdit1
        '
        Me.ImageComboBoxEdit1.Location = New System.Drawing.Point(86, 109)
        Me.ImageComboBoxEdit1.Name = "ImageComboBoxEdit1"
        Me.ImageComboBoxEdit1.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.ImageComboBoxEdit1.Properties.Items.AddRange(New DevExpress.XtraEditors.Controls.ImageComboBoxItem() {New DevExpress.XtraEditors.Controls.ImageComboBoxItem("Azure", "tcp:sqlmi-dps-prd-001.688137dfcb5d.database.windows.net,1433", -1)})
        Me.ImageComboBoxEdit1.Size = New System.Drawing.Size(100, 20)
        Me.ImageComboBoxEdit1.TabIndex = 0
        '
        'GridLookUpEdit1
        '
        Me.GridLookUpEdit1.Location = New System.Drawing.Point(86, 152)
        Me.GridLookUpEdit1.Name = "GridLookUpEdit1"
        Me.GridLookUpEdit1.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.GridLookUpEdit1.Properties.PopupView = Me.GridLookUpEdit1View
        Me.GridLookUpEdit1.Size = New System.Drawing.Size(100, 20)
        Me.GridLookUpEdit1.TabIndex = 1
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'TreeList1
        '
        Me.TreeList1.Columns.AddRange(New DevExpress.XtraTreeList.Columns.TreeListColumn() {Me.colEData, Me.colImageOrderList, Me.colImage})
        Me.TreeList1.DataSource = Me.DPSTreeListBindingSource
        Me.TreeList1.Location = New System.Drawing.Point(273, 91)
        Me.TreeList1.Name = "TreeList1"
        Me.TreeList1.Size = New System.Drawing.Size(400, 200)
        Me.TreeList1.TabIndex = 2
        '
        'colEData
        '
        Me.colEData.FieldName = "EData"
        Me.colEData.Name = "colEData"
        Me.colEData.Visible = True
        Me.colEData.VisibleIndex = 0
        '
        'colImageOrderList
        '
        Me.colImageOrderList.FieldName = "ImageOrderList"
        Me.colImageOrderList.Name = "colImageOrderList"
        Me.colImageOrderList.Visible = True
        Me.colImageOrderList.VisibleIndex = 1
        '
        'colImage
        '
        Me.colImage.FieldName = "Image"
        Me.colImage.Name = "colImage"
        Me.colImage.Visible = True
        Me.colImage.VisibleIndex = 2
        '
        'DPSTreeListBindingSource
        '
        Me.DPSTreeListBindingSource.DataMember = "DPS_TreeList"
        Me.DPSTreeListBindingSource.DataSource = Me.Ds_DPSTreelist
        '
        'Ds_DPSTreelist
        '
        Me.Ds_DPSTreelist.DataSetName = "Ds_DPSTreelist"
        Me.Ds_DPSTreelist.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DPS_TreeListTableAdapter
        '
        Me.DPS_TreeListTableAdapter.ClearBeforeFill = True
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Location = New System.Drawing.Point(99, 204)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(75, 23)
        Me.SimpleButton1.TabIndex = 3
        Me.SimpleButton1.Text = "SimpleButton1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.SimpleButton1)
        Me.Controls.Add(Me.TreeList1)
        Me.Controls.Add(Me.GridLookUpEdit1)
        Me.Controls.Add(Me.ImageComboBoxEdit1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.ImageComboBoxEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TreeList1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DPSTreeListBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ds_DPSTreelist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ImageComboBoxEdit1 As DevExpress.XtraEditors.ImageComboBoxEdit
    Friend WithEvents GridLookUpEdit1 As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents TreeList1 As DevExpress.XtraTreeList.TreeList
    Friend WithEvents Ds_DPSTreelist As Ds_DPSTreelist
    Friend WithEvents DPSTreeListBindingSource As BindingSource
    Friend WithEvents DPS_TreeListTableAdapter As Ds_DPSTreelistTableAdapters.DPS_TreeListTableAdapter
    Friend WithEvents colEData As DevExpress.XtraTreeList.Columns.TreeListColumn
    Friend WithEvents colImageOrderList As DevExpress.XtraTreeList.Columns.TreeListColumn
    Friend WithEvents colImage As DevExpress.XtraTreeList.Columns.TreeListColumn
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
End Class
