﻿Imports System.ComponentModel
Imports System.Text
Imports System.Data
'Imports System.Data.Sql
'Imports System.Data.SqlClient
Imports DevExpress.Data
Imports Microsoft.VisualBasic
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.Collections.Generic
Imports System.Windows.Forms
Imports DevExpress.XtraTab
Imports DevExpress.XtraTab.ViewInfo
Imports DevExpress.XtraGrid
Imports DevExpress.XtraEditors
Imports DevExpress.XtraEditors.Repository
Imports DevExpress.XtraEditors.DXErrorProvider
Imports DevExpress.XtraExport
Imports DevExpress.XtraEditors.Controls
Imports DevExpress.Utils.Menu
Imports DevExpress.LookAndFeel
Imports System.Drawing.Drawing2D
Imports DevExpress.Utils.Drawing
Imports DevExpress.XtraBars
Imports DevExpress.XtraPrinting.Preview
Imports DevExpress.XtraReports.UI
Imports System.Security.Principal
Imports System.Configuration
Imports System.Data.Common
Imports System.IO
Imports DevExpress.XtraGrid.Menu
Imports DevExpress.XtraPrinting
Imports DevExpress.XtraTreeList
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraGrid.Export
Imports DevExpress.XtraGrid.Views.Base
Imports DevExpress.XtraGrid.Columns
Imports DevExpress.XtraEditors.CheckEdit
Imports DevExpress.XtraGrid.Views.BandedGrid
Imports System.Linq
Imports System.Security
Imports DevExpress
Imports DevExpress.XtraTreeList.Nodes
Imports DevExpress.XtraTreeList.Columns
Imports System.Threading
Imports DevExpress.XtraSplashScreen
Imports DevExpress.Utils
Imports DevExpress.XtraExport.Helpers
Imports DevExpress.DashboardCommon
Imports DevExpress.DashboardCommon.ViewerData
Imports DevExpress.DashboardWin
Imports DevExpress.DataAccess
Imports DevExpress.ClipboardSource.SpreadsheetML
Imports DevExpress.DataAccess.ConnectionParameters
Imports DevExpress.XtraEditors.ViewInfo
Imports DevExpress.XtraGrid.Views.Grid.ViewInfo
Imports DevExpress.Export
Imports DevExpress.Skins
Imports Microsoft.Data.Sql
Imports Microsoft.Data.SqlClient
Imports Microsoft.Data.SqlClient.SqlConnection
Imports Azure.Identity


Public Class Form1



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private server As String
    Private connection2 As SqlConnection
    Private connectionstring As String
    Private Sub ImageComboBoxEdit1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ImageComboBoxEdit1.SelectedIndexChanged


        'Create an instance of InteractiveBrowserCredential
        Dim credential As New InteractiveBrowserCredential()

        Dim listDataBases As New List(Of String)()
        server = ImageComboBoxEdit1.EditValue.ToString

        connectionstring = "Data Source=" & server & " ; Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;"

        connection2 = New SqlConnection(connectionstring) ' Store the connection
        connection2.AccessToken = credential.GetToken(New Azure.Core.TokenRequestContext({"https://database.windows.net/.default"})).Token
        connection2.Open()

        Dim selectSQL As String = "Select name from sys.databases where name Like 'cw_%';"

        Using com As New SqlCommand(selectSQL, connection2)
            Using dr As SqlDataReader = com.ExecuteReader()
                While dr.Read()
                    listDataBases.Add(dr(0).ToString())
                End While
            End Using
        End Using

        GridLookUpEdit1.Properties.DataSource = listDataBases

    End Sub

    Private Sub SimpleButton1_Click(sender As Object, e As EventArgs) Handles SimpleButton1.Click


        connectionstring = "Server=" & ImageComboBoxEdit1.EditValue.ToString & "; Database=" & GridLookUpEdit1.EditValue.ToString & "; Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;"
        DPS_TreeListTableAdapter.Connection.ConnectionString = connectionstring
        Me.DPS_TreeListTableAdapter.Fill(Me.Ds_DPSTreelist.DPS_TreeList)


    End Sub
End Class
